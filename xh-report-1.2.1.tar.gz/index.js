function m(n) {
  "@babel/helpers - typeof";
  return m = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(r) {
    return typeof r;
  } : function(r) {
    return r && typeof Symbol == "function" && r.constructor === Symbol && r !== Symbol.prototype ? "symbol" : typeof r;
  }, m(n);
}
function P(n, r) {
  var e = Object.keys(n);
  if (Object.getOwnPropertySymbols) {
    var t = Object.getOwnPropertySymbols(n);
    r && (t = t.filter(function(i) {
      return Object.getOwnPropertyDescriptor(n, i).enumerable;
    })), e.push.apply(e, t);
  }
  return e;
}
function p(n) {
  for (var r = 1; r < arguments.length; r++) {
    var e = arguments[r] != null ? arguments[r] : {};
    r % 2 ? P(Object(e), !0).forEach(function(t) {
      d(n, t, e[t]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(e)) : P(Object(e)).forEach(function(t) {
      Object.defineProperty(n, t, Object.getOwnPropertyDescriptor(e, t));
    });
  }
  return n;
}
function d(n, r, e) {
  return r = L(r), r in n ? Object.defineProperty(n, r, { value: e, enumerable: !0, configurable: !0, writable: !0 }) : n[r] = e, n;
}
function A(n, r) {
  if (!(n instanceof r))
    throw new TypeError("Cannot call a class as a function");
}
function I(n, r) {
  for (var e = 0; e < r.length; e++) {
    var t = r[e];
    t.enumerable = t.enumerable || !1, t.configurable = !0, "value" in t && (t.writable = !0), Object.defineProperty(n, L(t.key), t);
  }
}
function R(n, r, e) {
  return r && I(n.prototype, r), e && I(n, e), Object.defineProperty(n, "prototype", { writable: !1 }), n;
}
function L(n) {
  var r = M(n, "string");
  return m(r) === "symbol" ? r : String(r);
}
function M(n, r) {
  if (m(n) !== "object" || n === null)
    return n;
  var e = n[Symbol.toPrimitive];
  if (e !== void 0) {
    var t = e.call(n, r || "default");
    if (m(t) !== "object")
      return t;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(n);
}
function x(n, r) {
  return j(n) || D(n, r) || X(n, r) || k();
}
function k() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function D(n, r) {
  var e = n == null ? null : typeof Symbol != "undefined" && n[Symbol.iterator] || n["@@iterator"];
  if (e != null) {
    var t, i, o, s, a = [], l = !0, u = !1;
    try {
      if (o = (e = e.call(n)).next, r === 0) {
        if (Object(e) !== e)
          return;
        l = !1;
      } else
        for (; !(l = (t = o.call(e)).done) && (a.push(t.value), a.length !== r); l = !0)
          ;
    } catch (c) {
      u = !0, i = c;
    } finally {
      try {
        if (!l && e.return != null && (s = e.return(), Object(s) !== s))
          return;
      } finally {
        if (u)
          throw i;
      }
    }
    return a;
  }
}
function j(n) {
  if (Array.isArray(n))
    return n;
}
function y(n, r) {
  var e = typeof Symbol != "undefined" && n[Symbol.iterator] || n["@@iterator"];
  if (!e) {
    if (Array.isArray(n) || (e = X(n)) || r && n && typeof n.length == "number") {
      e && (n = e);
      var t = 0, i = function() {
      };
      return { s: i, n: function() {
        return t >= n.length ? { done: !0 } : { done: !1, value: n[t++] };
      }, e: function(u) {
        throw u;
      }, f: i };
    }
    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  var o = !0, s = !1, a;
  return { s: function() {
    e = e.call(n);
  }, n: function() {
    var u = e.next();
    return o = u.done, u;
  }, e: function(u) {
    s = !0, a = u;
  }, f: function() {
    try {
      !o && e.return != null && e.return();
    } finally {
      if (s)
        throw a;
    }
  } };
}
function X(n, r) {
  if (n) {
    if (typeof n == "string")
      return S(n, r);
    var e = Object.prototype.toString.call(n).slice(8, -1);
    if (e === "Object" && n.constructor && (e = n.constructor.name), e === "Map" || e === "Set")
      return Array.from(n);
    if (e === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(e))
      return S(n, r);
  }
}
function S(n, r) {
  (r == null || r > n.length) && (r = n.length);
  for (var e = 0, t = new Array(r); e < r; e++)
    t[e] = n[e];
  return t;
}
var N = "1.2.1";
function E(n, r) {
  var e = "", t = "";
  for (var i in r)
    e += i + "=" + encodeURIComponent(r[i]) + "&";
  if (e = e.replace(/&$/, ""), n.includes("#/")) {
    var o = n.split("#/")[1];
    if (!o || !o.includes("?"))
      return n + "?" + e;
    var s = (o + "&" + e).split("?")[0], a = (o + "&" + e).split("?")[1], l = (a ? a.split("&") : []).reduce(function(u, c) {
      if (c && c.includes("=")) {
        var f = c.split("=");
        u[f[0]] = c.slice(f[0].length + 1);
      }
      return u;
    }, {});
    return n.split("#/")[0] + "#/" + E(s, l);
  }
  return /\?$/.test(n) ? t = n + e : t = n.replace(/\/?$/, "?") + e, t;
}
var T = function n(r) {
  var e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "date", t = new Date(r), i = t.getFullYear(), o = t.getMonth() + 1, s = t.getDate(), a = t.getHours(), l = t.getMinutes(), u = t.getSeconds();
  if (new Date(t).toString() === "Invalid Date" || !r) {
    if (/^\d{8}$/gi.test("".concat(r))) {
      var c = "".concat(r).split("").reduce(function(h, g, w) {
        var b = [3, 5].includes(w) ? "-" : "";
        return h + g + b;
      }, "");
      return n(c, e);
    }
    return "";
  }
  o < 10 && (o = "0" + o), s < 10 && (s = "0" + s), a < 10 && (a = "0" + a), l < 10 && (l = "0" + l), u < 10 && (u = "0" + u);
  var f;
  switch (e) {
    case "dateTime":
      f = "".concat(i, "-").concat(o, "-").concat(s, " ").concat(a, ":").concat(l, ":").concat(u);
      break;
    default:
      f = "".concat(i, "-").concat(o, "-").concat(s);
  }
  return f;
}, C = function() {
  var r = {
    Chrome: /Chrome/,
    IE: /MSIE/,
    Firefox: /Firefox/,
    Opera: /Presto/,
    Safari: /Version\/([\d.]+).*Safari/,
    360: /360SE/,
    QQBrowswe: /QQ/,
    Edge: /Edg/
  }, e = {
    iPhone: /iPhone/,
    iPad: /iPad/,
    Android: /Android/,
    Windows: /Windows/,
    Mac: /Macintosh/
  }, t = navigator.userAgent, i = {
    browserName: "",
    // 浏览器名称
    browserVersion: "",
    // 浏览器版本
    osName: "",
    // 操作系统名称
    osVersion: "",
    // 操作系统版本
    deviceName: "",
    // 设备名称
    dpi: 96,
    lang: navigator.language
  };
  try {
    for (var o in r)
      r[o].test(t) && (i.browserName = o, o === "Chrome" && t.split("Chrome/")[1] ? i.browserVersion = t.split("Chrome/")[1].split(" ")[0] : o === "IE" && t.split("MSIE ")[1] ? i.browserVersion = t.split("MSIE ")[1].split(" ")[1] : o === "Firefox" ? i.browserVersion = t.split("Firefox/")[1] : o === "Opera" ? i.browserVersion = t.split("Version/")[1] : o === "Safari" && t.split("Version/")[1] ? i.browserVersion = t.split("Version/")[1].split(" ")[0] : o === "360" ? i.browserVersion = "" : o === "QQBrowswe" && t.split("Version/")[1] ? i.browserVersion = t.split("Version/")[1].split(" ")[0] : o === "Edge" && t.split("Edg/")[1] && (i.browserVersion = t.split("Edg/")[1].split(" ")[0]));
    for (var s in e)
      if (e[s].test(t)) {
        if (i.osName = s, s === "Windows" && t.split("Windows NT ")[1])
          i.osVersion = t.split("Windows NT ")[1].split(";")[0];
        else if (s === "Mac" && t.split("Mac OS X ")[1])
          i.osVersion = t.split("Mac OS X ")[1].split(")")[0];
        else if (s === "iPhone" && t.split("iPhone OS ")[1])
          i.osVersion = t.split("iPhone OS ")[1].split(" ")[0];
        else if (s === "iPad" && t.split("iPad; CPU OS ")[1])
          i.osVersion = t.split("iPad; CPU OS ")[1].split(" ")[0];
        else if (s === "Android" && t.split("Android ")[1]) {
          i.osVersion = t.split("Android ")[1].split(";")[0];
          var a = t.split("(Linux; Android ")[1];
          a && a.split("; ")[1] && (i.deviceName = a.split("; ")[1].split(" Build")[0]);
        }
      }
    i.dpi = i.dpi * window.devicePixelRatio;
  } catch (l) {
    console.log(l);
  }
  return i;
}, q = function(r) {
  var e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "__uuid__";
  if (!r && e) {
    var t = window.localStorage.getItem(e);
    if (t)
      return t;
  }
  var i = (/* @__PURE__ */ new Date()).getTime(), o = "xxxxxxxxxxxxxxxxyxxxxxxxxxxxxxxx".replace(/[xy]/g, function(s) {
    var a = (i + Math.random() * 16) % 16 | 0;
    return i = Math.floor(i / 16), (s == "x" ? a : a & 3 | 8).toString(16);
  });
  return e && window.localStorage.setItem(e, o), o;
}, O = function() {
  var r = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [], e = {};
  if (window.location.search)
    try {
      var t = window.location.search.endsWith("/") ? window.location.search.slice(0, -1) : window.location.search, i = new URLSearchParams(t), o = y(i.entries()), s;
      try {
        for (o.s(); !(s = o.n()).done; ) {
          var a = x(s.value, 2), l = a[0], u = a[1];
          r.includes(l) || (e[l] = u);
        }
      } catch (v) {
        o.e(v);
      } finally {
        o.f();
      }
    } catch (v) {
      console.log(v);
    }
  if (window.location.hash && window.location.hash.includes("?"))
    try {
      var c = window.location.hash.endsWith("/") ? window.location.hash.slice(0, -1) : window.location.hash, f = new URLSearchParams(c.split("?")[1]), h = y(f.entries()), g;
      try {
        for (h.s(); !(g = h.n()).done; ) {
          var w = x(g.value, 2), b = w[0], V = w[1];
          r.includes(b) || (e[b] = V);
        }
      } catch (v) {
        h.e(v);
      } finally {
        h.f();
      }
    } catch (v) {
      console.log(v);
    }
  return e;
}, U = /* @__PURE__ */ function() {
  function n() {
    A(this, n);
  }
  return R(n, [{
    key: "request",
    value: function(e, t, i) {
      var o = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : "GET";
      return new Promise(function(s) {
        var a;
        try {
          a = new XMLHttpRequest();
        } catch (c) {
          a = new ActiveXObject("Microsoft.XMLHTTP");
        }
        var l = i && i.params || {};
        if (a.open(o, E(e, l), !0), i && i.headers)
          for (var u in i.headers)
            a.setRequestHeader(u, i.headers[u]);
        a.onreadystatechange = function() {
          if (a.readyState === 4) {
            var c = a.responseText;
            try {
              c = JSON.parse(a.responseText);
            } catch (f) {
            }
            s(c || {});
          }
        }, a.send(JSON.stringify(t));
      });
    }
  }, {
    key: "get",
    value: function(e) {
      var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
      return this.request(e, {}, t, "GET");
    }
  }, {
    key: "post",
    value: function(e) {
      var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      return this.request(e, t, i, "POST");
    }
  }]), n;
}(), H = function() {
  try {
    var r = new U(), e = r.request.bind(r);
    return e.get = r.get.bind(r), e.post = r.post.bind(r), e;
  } catch (t) {
    return console.log(t), function() {
      return Promise.resolve(arguments.length <= 0 ? void 0 : arguments[0]);
    };
  }
}, K = H(), _ = function(r) {
  return r && r.split(".").join("0");
}, W = /* @__PURE__ */ function() {
  function n(r) {
    A(this, n), d(this, "XH_ALIVE", "xh_alive"), d(this, "XH_HEART", "xh_heartbeat"), d(this, "xhMap", d({}, this.XH_ALIVE, "has_alive")), d(this, "sLogIdUrl", "__log_id_url__"), d(this, "sLogIdParams", "__log_id_params__"), d(this, "isDev", !1), d(this, "allKeyMap", []), d(this, "pkg", ""), d(this, "openId", ""), d(this, "versionName", "1.0.1"), d(this, "versionCode", _(this.versionName)), r && r.pkg && !r.manual ? this.init(r) : r && this.initParams(r), this.initParams = this.initParams.bind(this), this.ktk = this.ktk.bind(this), this.uuid = this.uuid.bind(this), this.initKeys = this.initKeys.bind(this), this.appendAllKeyMap = this.appendAllKeyMap.bind(this), this.getXhReportParams = this.getXhReportParams.bind(this), this.getLogIdUrl = this.getLogIdUrl.bind(this), this.getLogIdParams = this.getLogIdParams.bind(this), this.requestXhReport = this.requestXhReport.bind(this), this.init = this.init.bind(this);
  }
  return R(n, [{
    key: "initParams",
    value: function(e) {
      e && [!0, !1].includes(e.isDev) && (this.isDev = e.isDev), e && e.version && (this.versionName = e.version || "", this.versionCode = _(this.versionName)), e && e.pkg && (this.pkg = e.pkg), e && e.tk && (this.openId = e.tk, window.localStorage.setItem(this.ktk(this.pkg), this.openId)), this.openId = this.openId || this.uuid(this.pkg), this.initKeys(e.keys);
    }
  }, {
    key: "ktk",
    value: function(e) {
      return "__".concat(e || "xh_report", "__");
    }
  }, {
    key: "uuid",
    value: function(e) {
      return q(!1, this.ktk(e));
    }
  }, {
    key: "initKeys",
    value: function(e) {
      if (!(!e || !e.length)) {
        var t = y(e), i;
        try {
          for (t.s(); !(i = t.n()).done; ) {
            var o = i.value;
            this.allKeyMap.push({
              key: o.toUpperCase(),
              value: o.toLowerCase()
            });
          }
        } catch (s) {
          t.e(s);
        } finally {
          t.f();
        }
      }
    }
  }, {
    key: "appendAllKeyMap",
    value: function(e) {
      var t = y(this.allKeyMap), i;
      try {
        for (t.s(); !(i = t.n()).done; ) {
          var o = i.value;
          e[o.key] = o.value;
        }
      } catch (s) {
        t.e(s);
      } finally {
        t.f();
      }
    }
  }, {
    key: "getXhReportParams",
    value: function() {
      var e = C(), t = Date.now(), i = e.osName || e.browserName, o = e.osVersion || e.browserVersion;
      return {
        channel: "web",
        local: e.lang,
        appvn: this.versionName,
        plat: "web",
        app: this.pkg,
        tk: this.openId,
        ts: t,
        manu: i,
        sysv: o,
        model: o,
        anid: this.openId,
        oaid: this.openId,
        w: window.screen.width,
        h: window.screen.height,
        sdkvn: N
      };
    }
  }, {
    key: "getLogIdUrl",
    value: function() {
      var e = window.localStorage.getItem(this.sLogIdUrl);
      if (e)
        return e;
      window.localStorage.setItem(this.sLogIdUrl, window.location.href);
      try {
        var t = O();
        window.localStorage.setItem(this.sLogIdParams, JSON.stringify(t));
      } catch (i) {
      }
      return window.location.href;
    }
  }, {
    key: "getLogIdParams",
    value: function() {
      var e = {};
      try {
        var t = window.localStorage.getItem(this.sLogIdParams);
        t && (e = JSON.parse(t));
      } catch (i) {
      }
      return e;
    }
  }, {
    key: "requestXhReport",
    value: function(e) {
      var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1;
      if (!this.openId)
        throw new Error("XhReport 还未初始化");
      if (!this.pkg)
        throw new Error("XhReport 初始化时 pkg 必传");
      if (e === "pay_suc" && t && t.orderId) {
        var o = "__paid_".concat(t.orderId), s = window.localStorage.getItem(o);
        if (s && +s == 1)
          return Promise.resolve(-1);
        window.localStorage.setItem(o, "1");
      }
      if (!e)
        return Promise.resolve(-2);
      var a = this.getXhReportParams(), l = this.getLogIdParams(), u = O(), c = this.xhMap[e] || e, f = e === this.XH_HEART, h = f ? T(Date.now()) : "-1";
      if (i) {
        var g = window.localStorage.getItem(c);
        if (g && +g == 1 || f && g === h)
          return Promise.resolve(-1);
      }
      return f ? window.localStorage.setItem(c, h) : window.localStorage.setItem(c, "1"), this.isDev ? (console.log("%cXh Report%c ".concat(e), "background:#666;color:#fff;padding:3px 5px; border-radius:5px;", "color: #09f;", a, [{
        key: e,
        ext: p(p(p({}, l), t), {}, {
          logidUrl: this.getLogIdUrl()
        }, u),
        ts: a.ts
      }]), Promise.resolve(-2)) : K.post("https://xe.xdplt.com/adtrack", [{
        key: e,
        ext: p(p(p({}, l), t), {}, {
          logidUrl: this.getLogIdUrl()
        }, u),
        ts: a.ts
      }], {
        params: a
      });
    }
  }, {
    key: "init",
    value: function() {
      var e = this, t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
      this.initParams(t), this.requestXhReport(this.XH_ALIVE, {}, !0).then(function() {
      }).catch(function(i) {
        return console.log(i);
      }).finally(function() {
        e.requestXhReport(e.XH_HEART, {}, !0);
      });
    }
  }]), n;
}(), B = function(r) {
  try {
    var e = new W(r), t = e.requestXhReport.bind(e);
    return t.init = e.init.bind(e), t.uuid = e.uuid.bind(e), e.appendAllKeyMap(t), t;
  } catch (i) {
    return console.log(i), function() {
      return Promise.resolve(arguments.length <= 0 ? void 0 : arguments[0]);
    };
  }
};
export {
  B as default
};
